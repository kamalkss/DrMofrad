﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DrMofrad.Api.GraphQl.Gallery
{
    public record AddGalleryInput(string Title);
}
