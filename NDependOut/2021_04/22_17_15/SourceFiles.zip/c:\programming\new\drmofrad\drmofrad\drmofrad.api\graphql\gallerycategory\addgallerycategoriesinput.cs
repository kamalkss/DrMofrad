﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DrMofrad.Api.GraphQl.GalleryCategory
{
    public record AddGalleryCategoriesInput(string Title, string ImgUrl);
}
